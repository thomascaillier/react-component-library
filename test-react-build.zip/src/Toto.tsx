import './Toto.css'

export const Toto = () =>  {
    return (<span>TOTO</span>)
}
